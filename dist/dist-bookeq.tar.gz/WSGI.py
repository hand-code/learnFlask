__author__ = 'chenxiaofeng'

from bookeq import app
if __name__ == "__main__":
    app.run()
