import bookeq

if __name__ == '__main__':
    bookeq.app.run(debug=True)